"""Algorithm 1 — RC-based screening for high-order lagged Granger causality.

Runs the first stage of HDGRNN on a dataset: it builds the reservoir and the
lag/target pairs from the chronological *train* split, then searches over the
space of variable families (member reduction, family reduction, member
decomposition) to recover the high-order lagged Granger-causal structure.

Outputs (into --output, default ``outputs/<name>``):
    screening.json  families + per-step search logs + stats + config
    masks.npz       input masks per lag (consumed by stage 2 / HOGRNN)
    weights.npz     input weights per lag
    steps.csv       one row per search step

Example:
    python run_screening.py --config configs/lorenz.yaml
"""

import argparse
import json
from dataclasses import asdict
from pathlib import Path

import numpy as np
import pandas as pd

from hog_rnn.config import load_screening_config
from hog_rnn.data import chronological_split, load_series, screening_pairs
from hog_rnn.screening import screen_all_lags, serializable_screening

ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser(description="HDGRNN Algorithm 1: RC screening for lagged Granger causality")
    parser.add_argument("--config", required=True, help="path to a screening config yaml (data + screening)")
    parser.add_argument("--output", default=None, help="output directory (default: outputs/<config stem>)")
    parser.add_argument("--seed", type=int, default=None, help="override the screening seed")
    args = parser.parse_args()

    data, screening = load_screening_config(args.config)
    if args.seed is not None:
        screening.seed = args.seed

    values = load_series(data)
    split = chronological_split(values, data)
    lagged, target = screening_pairs(split.train, screening.max_lag, data.target)

    result = screen_all_lags(lagged, target, screening)

    name = Path(args.config).stem
    out_dir = Path(args.output) if args.output else ROOT / "outputs" / name
    out_dir.mkdir(parents=True, exist_ok=True)

    record = serializable_screening(result)
    record.update({
        "name": name,
        "variables": int(lagged.shape[-1]),
        "max_lag": screening.max_lag,
        "target": data.target,
        "config": {"data": asdict(data), "screening": asdict(screening)},
    })
    (out_dir / "screening.json").write_text(json.dumps(record, indent=2), encoding="utf-8")

    np.savez(out_dir / "masks.npz", **{f"lag_{i}": mask for i, mask in enumerate(result.masks)})
    np.savez(out_dir / "weights.npz", **{f"lag_{i}": weight for i, weight in enumerate(result.weights)})
    pd.DataFrame([asdict(item) for item in result.logs]).to_csv(out_dir / "steps.csv", index=False)

    print(json.dumps({
        "name": name,
        "variables": record["variables"],
        "max_lag": screening.max_lag,
        "families": record["families"],
        "evaluations": result.evaluations,
        "elapsed_seconds": round(result.elapsed_seconds, 3),
        "output_dir": str(out_dir),
    }, indent=2))


if __name__ == "__main__":
    main()
