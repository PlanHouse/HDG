from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple
import numpy as np


Family = Tuple[Tuple[int, ...], ...]


def canonical_family(family) -> Family:
    members = {tuple(sorted(set(map(int, member)))) for member in family if member}
    return tuple(sorted(members, key=lambda item: (len(item), item)))


def family_key(family: Family) -> str:
    return ";".join(",".join(map(str, member)) for member in canonical_family(family))


def member_block_mask(family: Family, dimension: int, variables: int) -> np.ndarray:
    family = canonical_family(family)
    mask = np.zeros((dimension, variables), dtype=float)
    if not family:
        return mask
    outer, outer_extra = divmod(dimension, variables)
    offset = 0
    for v in range(variables):
        outer_rows = outer + int(v < outer_extra)
        inner, inner_extra = divmod(outer_rows, len(family))
        for j, member in enumerate(family):
            block_rows = inner + int(j < inner_extra)
            if block_rows:
                mask[offset:offset + block_rows, list(member)] = 1.0
            offset += block_rows
    return mask


@dataclass
class ReservoirResult:
    error: float
    input_mask: np.ndarray
    input_weights: np.ndarray


class ReservoirEvaluator:
    def __init__(self, dimension: int, variables: int, seed: int, ridge: float, warmup: int,
                 input_scale: float, leak: float, bias: float, capacity_mode: str,
                 recurrent_seed: int | None = None):
        self.dimension = dimension
        self.variables = variables
        self.seed = seed
        self.ridge = ridge
        self.warmup = warmup
        self.input_scale = input_scale
        self.leak = leak
        self.bias = bias
        if capacity_mode != "member_blocks":
            raise ValueError("capacity_mode must be member_blocks")
        self.capacity_mode = capacity_mode
        self.recurrent_seed = 2025 if recurrent_seed is None else recurrent_seed
        recurrent_rng = np.random.default_rng(self.recurrent_seed)
        input_rng = np.random.default_rng(seed)
        q, _ = np.linalg.qr(recurrent_rng.normal(size=(dimension, dimension)))
        self.recurrent = q
        self.base_input_weights = input_rng.uniform(
            -input_scale, input_scale, size=(dimension, variables)
        )
        self.cache: dict[tuple[int, str], ReservoirResult] = {}

    def _mask(self, family: Family) -> np.ndarray:
        return member_block_mask(family, self.dimension, self.variables)

    def evaluate(self, lag_index: int, inputs: np.ndarray, target: np.ndarray, family: Family,
                 validation_fraction: float) -> ReservoirResult:
        family = canonical_family(family)
        key = (lag_index, family_key(family))
        if key in self.cache:
            return self.cache[key]
        mask = self._mask(family)
        win = self.base_input_weights * mask
        states = np.zeros((len(inputs), self.dimension), dtype=float)
        state = np.zeros(self.dimension, dtype=float)
        for index, current in enumerate(inputs):
            proposal = np.tanh(win @ current + self.recurrent @ state + self.bias)
            state = self.leak * state + (1.0 - self.leak) * proposal
            states[index] = state
        start = min(self.warmup, max(0, len(states) - 2))
        states, target = states[start:], target[start:]
        split = max(1, min(len(states) - 1, int(len(states) * (1.0 - validation_fraction))))
        x_train = np.column_stack([states[:split], np.ones(split)])
        x_valid = np.column_stack([states[split:], np.ones(len(states) - split)])
        gram = x_train.T @ x_train + self.ridge * np.eye(x_train.shape[1])
        coef = np.linalg.solve(gram, x_train.T @ target[:split])
        error = float(np.mean(np.abs(target[split:] - x_valid @ coef)))
        result = ReservoirResult(error=error, input_mask=mask, input_weights=win)
        self.cache[key] = result
        return result
