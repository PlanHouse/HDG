from dataclasses import dataclass
from pathlib import Path
from typing import Tuple
import yaml


@dataclass
class DataConfig:
    path: str
    format: str = "matrix"
    columns: list[str] | None = None
    target: int = 0
    length: int | None = None
    sequence_length: int = 100
    horizon: int = 5
    train_ratio: float = 0.6
    validation_ratio: float = 0.1
    normalize: bool = True


@dataclass
class ScreeningConfig:
    max_lag: int = 3
    reservoir_dim: int = 60
    warmup: int = 50
    ridge: float = 1e-8
    tolerance: float = 5e-7
    seed: int = 2025
    recurrent_seed: int | None = 2025
    input_scale: float = 0.1
    leak: float = 0.05
    bias: float = 1.0
    capacity_mode: str = "member_blocks"
    validation_fraction: float = 0.2


def load_screening_config(path: str | Path) -> Tuple[DataConfig, ScreeningConfig]:
    """Load the ``data`` and ``screening`` sections from a screening config file.

    This mirrors the subset of the original ``load_config`` that Algorithm 1
    depends on: the dataset description and the reservoir-screening hyperparameters.
    """
    path = Path(path).resolve()
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    data = DataConfig(**raw.pop("data"))
    screening = ScreeningConfig(**raw.pop("screening", {}))
    data_path = Path(data.path)
    if not data_path.is_absolute():
        data.path = str((path.parent / data_path).resolve())
    _validate(data, screening)
    return data, screening


def _validate(data: DataConfig, screening: ScreeningConfig) -> None:
    if data.sequence_length < 1 or data.horizon < 1:
        raise ValueError("sequence_length and horizon must be positive")
    if not 0 < data.train_ratio < 1:
        raise ValueError("train_ratio must be in (0, 1)")
    if not 0 < data.validation_ratio < 1 - data.train_ratio:
        raise ValueError("validation_ratio must leave a non-empty test split")
    if screening.capacity_mode != "member_blocks":
        raise ValueError("capacity_mode must be member_blocks")
