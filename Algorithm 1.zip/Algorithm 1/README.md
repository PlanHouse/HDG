# Algorithm 1 — RC-based screening for high-order lagged Granger causality

这是 HDGRNN 的**第一阶段**（论文 Algorithm 1）的独立抽取版本。它通过 Reservoir
Computing（RC）从时间序列中恢复**高阶时滞格兰杰因果结构**，输出每个滞后阶数下
被选中的变量族（family）及其对应的输入掩码（mask）与输入权重（weight）。这些
mask 随后作为结构化先验输入第二阶段的 HOGRNN 模型。

## 目录结构

```
Algorithm 1/
├── hog_rnn/
│   ├── __init__.py
│   ├── config.py       # DataConfig / ScreeningConfig / load_screening_config
│   ├── data.py         # 数据加载、时序切分、lag/target 构造
│   ├── reservoir.py    # ReservoirEvaluator + family/mask 构造（原样保留）
│   └── screening.py    # screen_lag / screen_all_lags 筛选算法主体（原样保留）
├── configs/            # 各数据集的 data + screening 配置
├── data/               # 数据文件
├── run_screening.py    # 运行入口
└── requirements.txt
```

## 与原项目的关系

本目录是原 `code/` 中第一阶段逻辑的精确抽取，未修改算法核心：

| 本目录文件 | 来源 | 说明 |
|---|---|---|
| `hog_rnn/reservoir.py` | `hog_rnn/reservoir.py` | 原样保留 |
| `hog_rnn/screening.py` | `hog_rnn/screening.py` | 原样保留 |
| `hog_rnn/config.py` | `hog_rnn/config.py` | 仅保留 `DataConfig`、`ScreeningConfig` 及配置加载 |
| `hog_rnn/data.py` | `hog_rnn/data.py` | 仅保留 `load_series`、`chronological_split`、`screening_pairs` |

第二阶段（`model.py`、`training.py`、`experiment.py`、`metrics.py`）依赖
PyTorch，不在此目录内，此处**不依赖 torch**。

## 运行

```bash
pip install -r requirements.txt
python run_screening.py --config configs/lorenz.yaml
```

可选参数：

- `--config`：配置文件路径（必填，包含 `data` 与 `screening` 两段）
- `--output`：输出目录（默认 `outputs/<配置文件名>`）
- `--seed`：覆盖配置文件中的筛选随机种子

## 输出

对每个数据集输出到 `outputs/<name>/`：

- `screening.json`：每个 lag 的变量族、逐步搜索日志、评估次数、耗时与所用配置
- `masks.npz`：每个 lag 的输入掩码（`lag_0`…`lag_{max_lag-1}`），供第二阶段使用
- `weights.npz`：每个 lag 的输入权重
- `steps.csv`：搜索过程中每一步的详细记录（operation / current / candidate / error / accepted）

## 算法要点

对每个滞后阶数 `lag`，`screen_lag` 从「所有变量构成单一族」出发，反复尝试三类
结构操作并以验证误差最小为准则接受改进，直至无法进一步降低误差：

1. **member_reduction**：单一族内剔除某个变量
2. **family_reduction**：从多个族中删除某一个族
3. **member_decomposition**：把族内某个变量拆分出去

候选误差由 `ReservoirEvaluator.evaluate` 计算：按 `member_block_mask` 分配水库
容量、迭代水库状态、以岭回归拟合目标并取验证集 MAE。最终每个 lag 得到的
`family` 与 `mask` 即该阶时滞下的格兰杰因果结构。
